%Parameter laden
Daten_opt = 1;
if Daten_opt == 1
    C_Parameter_DCDC_Wandler_opt
else
    B_Parameter_DCDC_Wandler
end
clear Daten_opt

%% Übertragungsfunktion der Regelstrecke (gemittelt zwischen Durchlass und Sperrbetrieb)
% --------------------------------------------------------------------------------------
% Lastwiderstand bei U_soll und einem Birnchen
Usoll = 5;
R_Last_Usoll_1B = interp1(KL_R_Last_1B(1,:),KL_R_Last_1B(2,:),Usoll);

% Zählerpolynom
num = [R_Last_Usoll_1B];
% Nennerpolynom im Durchlassbetrieb
den_D = [R_Last_Usoll_1B*L*C (R_Last_Usoll_1B*R_L*C+R_Last_Usoll_1B*R_VD*C+L) (R_L+R_VD+R_Last_Usoll_1B)];
% Nennerpolynom im Sperrbetrieb
den_S = [R_Last_Usoll_1B*L*C (R_Last_Usoll_1B*R_L*C+R_Last_Usoll_1B*R_VS*C+L) (R_L+R_VS+R_Last_Usoll_1B)];
% Nennerpolynom gemittelt
den = (den_D + den_S)/2;
% Übertragungsfunktion des DC-DC-Wandler (Eingangsgröße U)
G_DCDC = tf(num,den);
% Übertragungsfunktion der Regelstrecke (Eingangsgröße PWM, Ausgangsgröße U_a in mV)
G_S_Reg = 12/4095*G_DCDC*1000; 
% Bestimmung der Pole der Regelstrecke
Pole_S_Reg = pole(G_S_Reg);


%% Reglerauslegung
% ----------------
% Kompensation der langsamsten Zeitkonstante über die Nachstellzeit T_N
T_max = 1/min(abs(real(Pole_S_Reg)));
T_N = T_max;

% Übertragungsfunktion des Reglers (PI-Regler)
G_Regler_P = tf(1,1);                         % Übertragungsfunktion P-Regler mit Reglerverstärkung 1  
G_Regler_I = tf([1],[T_N 0]);                 % Übertragungsfunktion I-Regler mit Reglerverstärkung 1
G_Regler = parallel(G_Regler_P,G_Regler_I);   % Übertragungsfunktion des PI-Reglers in Parallelstruktur  

% Übertragungsfunktion des offenen Regelkreises
G_o = series(G_Regler,G_S_Reg);               % Übertragungsfunktion des offenen Regelkreises (inkl. Umrechnung PWM in mittlere Spannung u. Umrechnung Ausgangsspannung in mV)
G_o_PN = zpk(G_o);                            % Übertragungsfunktion in Pol-/Nullstellen Darstellung
Pole_Go = pole(G_o);                          % Polstellen des offenen Regelkreises

% Plotten der Wurzelortskurve
figure;rlocus(G_o,[0:0.001:100]);              % Wurzelortskurve mit den Gain-Werten [0:0.05:100]

% Auswahl und Festlegung der Reglerverstärkung
Kr = 0.005; % damit ergibt sich eine Zeitkonstante von etwa 10 ms

% übrige Reglerperameter
P_on = 1;
I_on = 1;
PWM_max = 4095;
PWM_min = 0;