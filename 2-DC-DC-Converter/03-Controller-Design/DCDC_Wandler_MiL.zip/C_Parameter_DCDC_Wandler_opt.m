L = 11.33e-3;   % Induktivit�t der Spule [H]
R_L = 18.84;    % Widerstand der Spule[Ohm]
C = 0.85e-6;    % Kapazit�t [F]

U_d = 0.6;      % Spannungsabfall �ber der Diode [V]

R_VD = 0.2;     % Verlustwiderstand im Durchlassbetrieb [Ohm]
R_VS = 0.75;    % Verlustwiderstand im Sperrbetrieb [Ohm]

B = 1;          % Anzahl der verwendeten Birnchen [1|2]

%Kennline des Lastwiderstands (1 Birnchen)
KL_R_Last_1B = [
    0.595   1.41    2.25    3.10    4.00    7.48    10.19   12.901
    30.94   49.25   59.67   68.31   75.56   97.26   110.42  122.10
    ];

%Kennline des Lastwiderstands (2 Birnchen)
KL_R_Last_2B = [
    0.398   1.059   1.765   2.432   3.841   5.267   6.782   7.605
    13.078  21.565  26.944  30.503  36.439  40.966  45.312  47.445
    ];