function [Zeit,D,U_Ausgang] = func_Daten_Import_DCDC(File,Path)

    [pathstr,name,ext] = fileparts(fullfile(Path,File));
    clear pathstr name
        switch ext
            case '.mat'
                load(fullfile(Path,File))
                disp(['geladener Datensatz: ' File]);
                Zeit = [0:double(Length-1)]*Tinterval;
                Zeit = Zeit';
                tstop = Zeit(end);
                D = double(A(1:Length))';
                U_Ausgang = double(B(1:Length)');
                clear Tinterval Tstart Length A B
        end
end

