%% Parameter laden
B_Parameter_DCDC_Wandler

%% Datenfile laden
Ca_Import_DCDC_Messdaten

%% Anzahl der Birnchen abfragen
answer = questdlg('Anzahl Birnchen feslegen', ...
	'Anzahl Birnchen', ...
	'1','2','1');

% Antwort auswerten
switch answer
    case '1'
        B = 1;
    case '2'
        B = 2;
end

clear answer

%% Optimierung starten

%Vektorraum erzeugen
Anz_Stuetzstellen = 5;
R_L_vec = linspace(0.9*R_L,1.1*R_L,Anz_Stuetzstellen);
R_VS_vec = linspace(0,2,Anz_Stuetzstellen);
L_vec = linspace(0.8*L,1.2*L,Anz_Stuetzstellen);
C_vec = linspace(0.8*C,1.2*C,Anz_Stuetzstellen);

%Simulationsparamter
SimStepSize = 1e-6;
tstop = floor(Zeit(end)/SimStepSize)*SimStepSize;

% Zähler initialisieren
Durchlaeufe = 0;

%Erzeugung waitbar
h_waitbar = waitbar(0,'Iteration läuft...');
Durchlaeufe_ges = Anz_Stuetzstellen^4;

for i = R_L_vec
    for j = R_VS_vec
        for k = L_vec
            for l = C_vec
                % Counter incrementieren
                Durchlaeufe = Durchlaeufe + 1;
                % waitbar updaten
                waitbar(Durchlaeufe/Durchlaeufe_ges)

                % Variablen für Simulation belegen
                R_L = i;
                R_VS = j;
                L = k;
                C = l;

                %Simulation ausführen
                Daten = sim("A_Modell_DCDC_Wandler_opt.slx");
                
                %Auswertung der Ergebnisse
                Start_Index = floor(length(Daten)*0.5); % Um Fehlerquadratsumme über die 2. Hälfte der Simulationszeit zu berechnen
                J(Durchlaeufe) = sum((SimDaten.signals(2).values(Start_Index:end)-SimDaten.signals(3).values(Start_Index:end)).^2);
                if Durchlaeufe == 1
                    J_opt = J(Durchlaeufe);
                    R_L_opt = R_L;
                    R_VS_opt = R_VS;
                    L_opt = L;
                    C_opt = C;
                else
                    if J(Durchlaeufe) < J_opt
                        J_opt = J(Durchlaeufe);
                        R_L_opt = R_L;
                        R_VS_opt = R_VS;
                        L_opt = L;
                        C_opt = C;
                    end
                end                       
            end
        end
    end
end

% waitbar schliessen
close(h_waitbar) 

%% Ausgabe des optimalen Parametersatzes
disp('die beste Parameterkombination lautet')
disp('-------------------------------------')
disp(['R_L  = ' num2str(R_L_opt) ' Ohm'])
disp(['R_VS = ' num2str(R_VS_opt) ' Ohm'])
disp(['L    = ' num2str(L_opt) ' H'])
disp(['C    = ' num2str(C_opt) ' F'])

%% Simulation mit optimalem Parametersatz
R_L = R_L_opt;
R_VS = R_VS_opt;
L = L_opt;
C = C_opt;

Daten = sim("A_Modell_DCDC_Wandler_opt.slx");

%% Plotten der Daten nach Optimierung

%Figure erzeugen
Fig = figure;
Fig.Color = [1 1 1];       %RGB-Farbdefinition des Fenster-Hintergrunds
Fig.Units = "normalized";
Fig.Position = [0.3 0.3 0.4 0.4];

%Achsenkreuz erzeugen und formatieren
Achse_SimDaten = axes;                                               %Achsensystem erzeugen
Linie_Messdaten = plot(SimDaten.time,SimDaten.signals(3).values);    %Linie der Messdaten plotten
Achse_SimDaten.NextPlot = 'add';
Linie_SimDaten = plot(SimDaten.time,SimDaten.signals(2).values);     %Linie der Simulationsdaten plotten
Achse_SimDaten.Title.String = 'Ausgangsspannung DC-DC-Wandler';
Achse_SimDaten.Title.Color = 'k';
Achse_SimDaten.Title.FontWeight = 'bold';
Achse_SimDaten.XLabel.String = 'Zeit [s]';
Achse_SimDaten.YLabel.String = 'U_a [V]';
Achse_SimDaten.XGrid = 'on';
Achse_SimDaten.YGrid = 'on';

Linie_Messdaten.LineWidth = 2;
Linie_Messdaten.LineStyle = '-';
Linie_Messdaten.Color = 'b';

Linie_SimDaten.LineWidth = 2;
Linie_SimDaten.LineStyle = '-';
Linie_SimDaten.Color = 'r';

Legend = legend(Achse_SimDaten,[Linie_Messdaten Linie_SimDaten],'Messwerte','optimierte Simulation');
Legend.Location = "northeast";
Legend.FontSize = 14;

% Zoom konfigurieren
Zoom = zoom(Fig);
Zoom.Motion = 'horizontal';
Zoom.Direction = 'in';
Zoom.Enable = 'on';







