ActPath = pwd;
addpath([ActPath '/Funktionen']);
clear ActPath

%Laden der Daten
[File,Path] = uigetfile({'*.mat','Messdaten-Files (*.mat)';'*.*',  'All Files (*.*)'}, ...
   'W�hlen Sie ein Messdaten-File');
if ~isnumeric(File)
    [Zeit,D,U_a] = func_Daten_Import_DCDC(File,Path);
    
    %Bereichs�berschreitungen (f�hrt zu inf-Werten) entfernen
    remove_inf = 1;
    if (remove_inf == 1)
        %% U_a
        Indizes = find(isinf(U_a));
        if (~isempty(Indizes))
            Temp = U_a;
            Temp(Indizes) = [];
            Temp = max(Temp);
            U_a(Indizes) = Temp;
            clear Temp
        end
        %% D
        Indizes = find(isinf(D));
        if (~isempty(Indizes))
            Temp = D;
            Temp(Indizes) = [];
            Temp = max(Temp);
            D(Indizes) = Temp;
            clear Temp
        end
        clear Indizes
    end
end

clear File Path ActPath remove_inf