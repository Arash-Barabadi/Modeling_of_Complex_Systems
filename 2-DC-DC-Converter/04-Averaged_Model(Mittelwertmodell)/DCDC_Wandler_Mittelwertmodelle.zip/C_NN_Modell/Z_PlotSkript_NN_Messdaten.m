% Daten laden
addpath('Messdaten')
load('Messdaten_DCDC_NN_gesamt.mat')

%Extrahieren der Werte aus Array Inputs_NN
PWM = Inputs_NN(:,1);
Freq = Inputs_NN(:,2);
B = Inputs_NN(:,3);

%Figure erzeugen
Fig = figure;
Fig.Color = [0.95 0.95 0.95];       %RGB-Farbdefinition des Fenster-Hintergrunds
Fig.Units = "normalized";
Fig.Position = [0.1 0.1 0.8 0.8];

%Achsenkreuz f�r PWM-Verlauf erzeugen und formatieren
Achse_PWM = axes;              
Achse_PWM.Units = 'normalized';
Achse_PWM.Position = [0.05 0.72 0.4 0.25];
Linie_PWM = plot(Zeit,PWM);   %Linie plotten
Achse_PWM.Title.String = 'PWM-Werte';
Achse_PWM.Title.Color = 'k';
Achse_PWM.Title.FontWeight = 'bold';
Achse_PWM.XLabel.String = 'Zeit [s]';
Achse_PWM.YLabel.String = 'PWM-Wert [0..4095]';
Achse_PWM.XGrid = 'on';
Achse_PWM.YGrid = 'on';
Linie_PWM.LineWidth = 2;
Linie_PWM.LineStyle = '-';
Linie_PWM.Color = 'b';

%Achsenkreuz f�r Frequenz-Verlauf erzeugen und formatieren
Achse_Freq = axes;              
Achse_Freq.Units = 'normalized';
Achse_Freq.Position = [0.05 0.38 0.4 0.25];
Linie_Freq = plot(Zeit,Freq);   %Linie plotten
Achse_Freq.Title.String = 'Frequenz-Werte';
Achse_Freq.Title.Color = 'k';
Achse_Freq.Title.FontWeight = 'bold';
Achse_Freq.XLabel.String = 'Zeit [s]';
Achse_Freq.YLabel.String = 'Frequenz [Hz]';
Achse_Freq.XGrid = 'on';
Achse_Freq.YGrid = 'on';
Linie_Freq.LineWidth = 2;
Linie_Freq.LineStyle = '-';
Linie_Freq.Color = 'r';

%Achsenkreuz f�r Birnchen-Verlauf erzeugen und formatieren
Achse_B = axes;              
Achse_B.Units = 'normalized';
Achse_B.Position = [0.05 0.05 0.4 0.25];
Linie_B = plot(Zeit,B);   %Linie plotten
Achse_B.Title.String = 'Birnchen';
Achse_B.Title.Color = 'k';
Achse_B.Title.FontWeight = 'bold';
Achse_B.XLabel.String = 'Zeit [s]';
Achse_B.YLabel.String = 'Birnchen [1|2]';
Achse_B.XGrid = 'on';
Achse_B.YGrid = 'on';
Linie_B.LineWidth = 2;
Linie_B.LineStyle = '-';
Linie_B.Color = [0 0.5 0];

%Achsenkreuz f�r Ausgangsspannungs-Verlauf erzeugen und formatieren
Achse_Ua = axes;              
Achse_Ua.Units = 'normalized';
Achse_Ua.Position = [0.55 0.35 0.4 0.4];
Linie_Ua = plot(Zeit,Spannung);   %Linie plotten
Achse_Ua.Title.String = 'Ausgangsspannung DC-DC Wandler';
Achse_Ua.Title.Color = 'k';
Achse_Ua.Title.FontWeight = 'bold';
Achse_Ua.XLabel.String = 'Zeit [s]';
Achse_Ua.YLabel.String = 'U_a [V]';
Achse_Ua.XGrid = 'on';
Achse_Ua.YGrid = 'on';
Linie_Ua.LineWidth = 2;
Linie_Ua.LineStyle = '-';
Linie_Ua.Color = [0 0.5 0];

linkaxes([Achse_PWM,Achse_Freq,Achse_B,Achse_Ua],'x')

Achse_PWM.XLim = [Zeit(1) Zeit(end)];
z = zoom;
z.Enable = 'on';
z.Motion = 'horizontal';
