% Daten KF-Modell laden
Parameter_DCDC_Wandler_MW_KF

% Daten theoretisches Modell laden
Parameter_DCDC_Wandler_MW_theo