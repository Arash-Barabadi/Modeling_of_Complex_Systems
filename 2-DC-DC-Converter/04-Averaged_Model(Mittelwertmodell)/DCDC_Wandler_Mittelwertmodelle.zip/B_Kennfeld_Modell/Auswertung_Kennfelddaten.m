ActPath = pwd;
%Pfad f�r Funktionen
addpath([ActPath '/Funktionen'])

%Pfad f�r Messdaten ausw�hlen
ui_data_path_on = 0;
if ui_data_path_on == 1
    data_path = uigetdir([ActPath '/Messdaten'],'Pfad der Messdateien ausw�hlen');
else
    data_path = [ActPath '/Messdaten'];
end
clear ui_data_path_on


%Auswertung Der Kennfelddaten
cd(data_path)
[filename_mat,pathname_mat] = uigetfile({'*.mat'},'Messdatenfiles f�r Ermittlung Kennfelddaten ausw�hlen','MultiSelect','on');
cd(ActPath)
if ~isnumeric(filename_mat)
    if iscell(filename_mat)
        for i = 1:length(filename_mat)
            load(fullfile(pathname_mat,filename_mat{i}));
            % Infos zusammenbauen
            Infos.fileName = filename_mat{i};
            % GUI erzeugen
            GUI_Kennfelddaten(Zeit,Spannung,Frequenz,PWM,Infos)
        end
    else
        load(fullfile(pathname_mat,filename_mat));
        % Infos zusammenbauen
        Infos.fileName = filename_mat;
        % GUI erzeugen
        GUI_Kennfelddaten(Zeit,Spannung,Frequenz,PWM,Infos)
    end
end

clear ActPath filename_mat pathname_mat Zeit Spannung Frequenz PWM i data_path Infos